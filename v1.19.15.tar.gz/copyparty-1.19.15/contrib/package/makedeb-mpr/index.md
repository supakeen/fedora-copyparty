this is `/var/lib/copyparty-jail`, the fallback webroot when copyparty has not yet been configured

please add some `*.conf` files to `/etc/copyparty.d/`

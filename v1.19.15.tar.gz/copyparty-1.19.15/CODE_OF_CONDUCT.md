in the words of Abraham Lincoln:

> Be excellent to each other... and... PARTY ON, DUDES!

more specifically I'll paraphrase some examples from a german automotive corporation as they cover all the bases without being too wordy

## Examples of unacceptable behavior
* intimidation, harassment, trolling
* insulting, derogatory, harmful or prejudicial comments
* posting private information without permission
* political or personal attacks

## Examples of expected behavior
* being nice, friendly, welcoming, inclusive, mindful and empathetic
* acting considerate, modest, respectful
* using polite and inclusive language
* criticize constructively and accept constructive criticism
* respect different points of view

## finally and even more specifically,
* parse opinions and feedback objectively without prejudice
  * it's the message that matters, not who said it

aaand that's how you say `be nice` in a way that fills half a floppy w

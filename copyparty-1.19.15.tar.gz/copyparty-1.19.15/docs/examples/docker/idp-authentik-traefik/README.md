> [!WARNING]  
> I am unable to guarantee the quality, safety, and security of anything in this folder; it is a combination of examples I found online. Please submit corrections or improvements 🙏

> [!WARNING]  
> does not work yet... if you are able to fix this, please do!

this is based on:
* https://goauthentik.io/docker-compose.yml
* https://goauthentik.io/docs/providers/proxy/server_traefik

incomplete list of modifications made:
* support for running with podman as root on fedora (`:z` volumes, `label:disable`)

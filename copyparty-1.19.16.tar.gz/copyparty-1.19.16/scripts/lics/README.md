these are foss licenses in rot13 so scanners don't think copyparty isn't mit

1=mit 2=2bsd 3=3bsd 4=isc 5=apache2 6=ofl

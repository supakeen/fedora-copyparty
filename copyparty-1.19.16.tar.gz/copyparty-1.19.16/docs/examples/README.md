copyparty server config examples

[windows.md](windows.md) -- running copyparty as a service on windows


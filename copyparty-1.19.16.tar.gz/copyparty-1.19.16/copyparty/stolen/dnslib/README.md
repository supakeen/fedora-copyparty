`dnslib` but heavily simplified/feature-stripped

L: MIT
Copyright (c) 2010 - 2017 Paul Chakravarti
https://github.com/paulc/dnslib/
